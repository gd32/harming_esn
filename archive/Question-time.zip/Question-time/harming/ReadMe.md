How to use:
1. Put Game.py, Player.py, process.py, and csv files in the same folder.
2. Move to the directory which has files above. 
3. run the follwing letters, "python process.py [A CSV FILE NAME]" 

Setting:
Python 3.10.5
networkx 2.8.7
matplotlib 3.6.1

